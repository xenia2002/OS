chmod u+x ~/Lab2/script.sh

